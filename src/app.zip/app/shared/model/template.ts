export class Usertemplate {
    username: string;
    password: string;
    email: string;
}