export interface Ireactive {
    username: string;
    password: string;
    email: string;
    UserLogin: {
        userid: string;
        mobileNo: string;
    }
}