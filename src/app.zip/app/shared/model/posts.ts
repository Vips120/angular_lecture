export interface Ipost {
    userId: number;
    id: number;
    title: string;
    body: string;
}