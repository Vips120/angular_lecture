import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders} from "@angular/common/http";
import { Iregister, Ilogin } from '../model/userRegister';
import { map } from "rxjs/operators";
@Injectable({providedIn:"root"})
export class UserRegister {
    private REGISTER_ENDPOINT = "http://mobile.test.acorsociety.com/ideators/api/users/userregistrationasync";
    private LOGIN_ENDPOINT = "http://mobile.test.acorsociety.com/ideators/api/users/userloginasync"
    public headers;

    constructor(private http: HttpClient) { 
        this.headers = new HttpHeaders({"Content-Type": "application/json"})
    }
    Registeration(data: Iregister) {
        return this.http.post(this.REGISTER_ENDPOINT, JSON.stringify(data), {headers: this.headers});
    };

    Login(data: Ilogin) {
        return this.http.post(this.LOGIN_ENDPOINT, JSON.stringify(data), { headers: this.headers })
            .pipe(map((item: any) => {
                if (item && item.UserLogin.JwtToken) {
                    localStorage.setItem("currentuser", JSON.stringify(item));
                } else {
                    return item;
                }
            })); 
    };

    Logout() {
        localStorage.removeItem("currentuser");
    }
}