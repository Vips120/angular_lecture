import { Route } from "@angular/router";
import { ContactComponent } from './contact.component';

export const contactroutes: Route[] = [
    {
        path: "",
        component: ContactComponent
    }
]