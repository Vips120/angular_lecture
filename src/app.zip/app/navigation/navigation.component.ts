import { Component, OnInit } from '@angular/core';
import { UserRegister } from '../shared/services/user.register';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css']
})
export class NavigationComponent implements OnInit {

  constructor(private userRegister: UserRegister) { }

  ngOnInit() {
  }
  Logout() {
    this.userRegister.Logout();
  }
}
