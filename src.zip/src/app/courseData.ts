export class CourseData {
    getCourse(): string[] {
        return ["Angular", "typescript", "javascript"]
    }
}