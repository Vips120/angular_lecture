export interface Iemployee {
    id: number;
    name: string;
}